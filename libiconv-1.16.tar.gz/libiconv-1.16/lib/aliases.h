/* ANSI-C code produced by gperf version 3.0.3 */
/* Command-line: gperf -t -L ANSI-C -H aliases_hash -N aliases_lookup -G -W aliases -7 -C -k '1,3-11,$' -i 1 aliases.gperf  */

#if !((' ' == 32) && ('!' == 33) && ('"' == 34) && ('#' == 35) \
      && ('%' == 37) && ('&' == 38) && ('\'' == 39) && ('(' == 40) \
      && (')' == 41) && ('*' == 42) && ('+' == 43) && (',' == 44) \
      && ('-' == 45) && ('.' == 46) && ('/' == 47) && ('0' == 48) \
      && ('1' == 49) && ('2' == 50) && ('3' == 51) && ('4' == 52) \
      && ('5' == 53) && ('6' == 54) && ('7' == 55) && ('8' == 56) \
      && ('9' == 57) && (':' == 58) && (';' == 59) && ('<' == 60) \
      && ('=' == 61) && ('>' == 62) && ('?' == 63) && ('A' == 65) \
      && ('B' == 66) && ('C' == 67) && ('D' == 68) && ('E' == 69) \
      && ('F' == 70) && ('G' == 71) && ('H' == 72) && ('I' == 73) \
      && ('J' == 74) && ('K' == 75) && ('L' == 76) && ('M' == 77) \
      && ('N' == 78) && ('O' == 79) && ('P' == 80) && ('Q' == 81) \
      && ('R' == 82) && ('S' == 83) && ('T' == 84) && ('U' == 85) \
      && ('V' == 86) && ('W' == 87) && ('X' == 88) && ('Y' == 89) \
      && ('Z' == 90) && ('[' == 91) && ('\\' == 92) && (']' == 93) \
      && ('^' == 94) && ('_' == 95) && ('a' == 97) && ('b' == 98) \
      && ('c' == 99) && ('d' == 100) && ('e' == 101) && ('f' == 102) \
      && ('g' == 103) && ('h' == 104) && ('i' == 105) && ('j' == 106) \
      && ('k' == 107) && ('l' == 108) && ('m' == 109) && ('n' == 110) \
      && ('o' == 111) && ('p' == 112) && ('q' == 113) && ('r' == 114) \
      && ('s' == 115) && ('t' == 116) && ('u' == 117) && ('v' == 118) \
      && ('w' == 119) && ('x' == 120) && ('y' == 121) && ('z' == 122) \
      && ('{' == 123) && ('|' == 124) && ('}' == 125) && ('~' == 126))
/* The character set is not based on ISO-646.  */
#error "gperf generated tables don't work with this execution character set. Please report a bug to <bug-gnu-gperf@gnu.org>."
#endif

#line 1 "aliases.gperf"
struct alias { int name; unsigned int encoding_index; };

#define TOTAL_KEYWORDS 55
#define MIN_WORD_LENGTH 2
#define MAX_WORD_LENGTH 17
#define MIN_HASH_VALUE 4
#define MAX_HASH_VALUE 115
/* maximum key range = 112, duplicates = 0 */

#ifdef __GNUC__
__inline
#else
#ifdef __cplusplus
inline
#endif
#endif
static unsigned int
aliases_hash (register const char *str, register unsigned int len)
{
  static const unsigned char asso_values[] =
    {
      116, 116, 116, 116, 116, 116, 116, 116, 116, 116,
      116, 116, 116, 116, 116, 116, 116, 116, 116, 116,
      116, 116, 116, 116, 116, 116, 116, 116, 116, 116,
      116, 116, 116, 116, 116, 116, 116, 116, 116, 116,
      116, 116, 116, 116, 116,   1,   1, 116,  26,   6,
       11,  21,   1,   1,   6,   1,  16,  21,   1, 116,
      116, 116, 116, 116, 116,  46,   6,   1,   1,   1,
        6,  21, 116,   1,   1, 116,   1,  26,   6,   1,
        1, 116,   1,   1,  21,   1,   6,   1,   1, 116,
      116, 116, 116, 116, 116,   6, 116, 116, 116, 116,
      116, 116, 116, 116, 116, 116, 116, 116, 116, 116,
      116, 116, 116, 116, 116, 116, 116, 116, 116, 116,
      116, 116, 116, 116, 116, 116, 116, 116
    };
  register int hval = len;

  switch (hval)
    {
      default:
        hval += asso_values[(unsigned char)str[10]];
      /*FALLTHROUGH*/
      case 10:
        hval += asso_values[(unsigned char)str[9]];
      /*FALLTHROUGH*/
      case 9:
        hval += asso_values[(unsigned char)str[8]];
      /*FALLTHROUGH*/
      case 8:
        hval += asso_values[(unsigned char)str[7]];
      /*FALLTHROUGH*/
      case 7:
        hval += asso_values[(unsigned char)str[6]];
      /*FALLTHROUGH*/
      case 6:
        hval += asso_values[(unsigned char)str[5]];
      /*FALLTHROUGH*/
      case 5:
        hval += asso_values[(unsigned char)str[4]];
      /*FALLTHROUGH*/
      case 4:
        hval += asso_values[(unsigned char)str[3]];
      /*FALLTHROUGH*/
      case 3:
        hval += asso_values[(unsigned char)str[2]];
      /*FALLTHROUGH*/
      case 2:
      case 1:
        hval += asso_values[(unsigned char)str[0]];
        break;
    }
  return hval + asso_values[(unsigned char)str[len - 1]];
}

struct stringpool_t
  {
    char stringpool_str4[sizeof("US")];
    char stringpool_str9[sizeof("L1")];
    char stringpool_str10[sizeof("UCS-4")];
    char stringpool_str12[sizeof("CSUCS4")];
    char stringpool_str14[sizeof("UCS-4LE")];
    char stringpool_str15[sizeof("UTF-7")];
    char stringpool_str19[sizeof("UCS-4BE")];
    char stringpool_str20[sizeof("EUCCN")];
    char stringpool_str22[sizeof("EUC-CN")];
    char stringpool_str23[sizeof("CSUNICODE")];
    char stringpool_str24[sizeof("UCS-2LE")];
    char stringpool_str26[sizeof("ISO-IR-6")];
    char stringpool_str28[sizeof("ISO646-US")];
    char stringpool_str29[sizeof("UCS-2BE")];
    char stringpool_str30[sizeof("UCS-2")];
    char stringpool_str31[sizeof("UTF-16LE")];
    char stringpool_str32[sizeof("UTF-16")];
    char stringpool_str35[sizeof("CP367")];
    char stringpool_str36[sizeof("UTF-16BE")];
    char stringpool_str37[sizeof("UNICODE-1-1")];
    char stringpool_str38[sizeof("UNICODE-1-1-UTF-7")];
    char stringpool_str40[sizeof("CN-GB")];
    char stringpool_str41[sizeof("CSUNICODE11UTF7")];
    char stringpool_str42[sizeof("CSUNICODE11")];
    char stringpool_str45[sizeof("UTF-8")];
    char stringpool_str46[sizeof("C99")];
    char stringpool_str47[sizeof("LATIN1")];
    char stringpool_str50[sizeof("UCS-4-INTERNAL")];
    char stringpool_str51[sizeof("UTF-32LE")];
    char stringpool_str52[sizeof("ISO_646.IRV:1991")];
    char stringpool_str55[sizeof("ASCII")];
    char stringpool_str56[sizeof("UTF-32BE")];
    char stringpool_str57[sizeof("UTF-32")];
    char stringpool_str59[sizeof("CSASCII")];
    char stringpool_str60[sizeof("UCS-2-INTERNAL")];
    char stringpool_str61[sizeof("US-ASCII")];
    char stringpool_str62[sizeof("IBM367")];
    char stringpool_str64[sizeof("UNICODELITTLE")];
    char stringpool_str65[sizeof("UNICODEBIG")];
    char stringpool_str66[sizeof("ISO-10646-UCS-4")];
    char stringpool_str69[sizeof("UCS-4-SWAPPED")];
    char stringpool_str70[sizeof("CP819")];
    char stringpool_str76[sizeof("ISO-10646-UCS-2")];
    char stringpool_str79[sizeof("UCS-2-SWAPPED")];
    char stringpool_str80[sizeof("ISO-8859-1")];
    char stringpool_str85[sizeof("ISO_8859-1")];
    char stringpool_str86[sizeof("ISO_8859-1:1987")];
    char stringpool_str87[sizeof("GB2312")];
    char stringpool_str96[sizeof("CSGB2312")];
    char stringpool_str97[sizeof("IBM819")];
    char stringpool_str100[sizeof("ISO-IR-100")];
    char stringpool_str102[sizeof("CSISOLATIN1")];
    char stringpool_str103[sizeof("JAVA")];
    char stringpool_str105[sizeof("ANSI_X3.4-1986")];
    char stringpool_str115[sizeof("ANSI_X3.4-1968")];
  };
static const struct stringpool_t stringpool_contents =
  {
    "US",
    "L1",
    "UCS-4",
    "CSUCS4",
    "UCS-4LE",
    "UTF-7",
    "UCS-4BE",
    "EUCCN",
    "EUC-CN",
    "CSUNICODE",
    "UCS-2LE",
    "ISO-IR-6",
    "ISO646-US",
    "UCS-2BE",
    "UCS-2",
    "UTF-16LE",
    "UTF-16",
    "CP367",
    "UTF-16BE",
    "UNICODE-1-1",
    "UNICODE-1-1-UTF-7",
    "CN-GB",
    "CSUNICODE11UTF7",
    "CSUNICODE11",
    "UTF-8",
    "C99",
    "LATIN1",
    "UCS-4-INTERNAL",
    "UTF-32LE",
    "ISO_646.IRV:1991",
    "ASCII",
    "UTF-32BE",
    "UTF-32",
    "CSASCII",
    "UCS-2-INTERNAL",
    "US-ASCII",
    "IBM367",
    "UNICODELITTLE",
    "UNICODEBIG",
    "ISO-10646-UCS-4",
    "UCS-4-SWAPPED",
    "CP819",
    "ISO-10646-UCS-2",
    "UCS-2-SWAPPED",
    "ISO-8859-1",
    "ISO_8859-1",
    "ISO_8859-1:1987",
    "GB2312",
    "CSGB2312",
    "IBM819",
    "ISO-IR-100",
    "CSISOLATIN1",
    "JAVA",
    "ANSI_X3.4-1986",
    "ANSI_X3.4-1968"
  };
#define stringpool ((const char *) &stringpool_contents)

static const struct alias aliases[] =
  {
    {-1}, {-1}, {-1}, {-1},
#line 21 "aliases.gperf"
    {(int)(long)&((struct stringpool_t *)0)->stringpool_str4, ei_ascii},
    {-1}, {-1}, {-1}, {-1},
#line 60 "aliases.gperf"
    {(int)(long)&((struct stringpool_t *)0)->stringpool_str9, ei_iso8859_1},
#line 33 "aliases.gperf"
    {(int)(long)&((struct stringpool_t *)0)->stringpool_str10, ei_ucs4},
    {-1},
#line 35 "aliases.gperf"
    {(int)(long)&((struct stringpool_t *)0)->stringpool_str12, ei_ucs4},
    {-1},
#line 37 "aliases.gperf"
    {(int)(long)&((struct stringpool_t *)0)->stringpool_str14, ei_ucs4le},
#line 44 "aliases.gperf"
    {(int)(long)&((struct stringpool_t *)0)->stringpool_str15, ei_utf7},
    {-1}, {-1}, {-1},
#line 36 "aliases.gperf"
    {(int)(long)&((struct stringpool_t *)0)->stringpool_str19, ei_ucs4be},
#line 63 "aliases.gperf"
    {(int)(long)&((struct stringpool_t *)0)->stringpool_str20, ei_euc_cn},
    {-1},
#line 62 "aliases.gperf"
    {(int)(long)&((struct stringpool_t *)0)->stringpool_str22, ei_euc_cn},
#line 26 "aliases.gperf"
    {(int)(long)&((struct stringpool_t *)0)->stringpool_str23, ei_ucs2},
#line 31 "aliases.gperf"
    {(int)(long)&((struct stringpool_t *)0)->stringpool_str24, ei_ucs2le},
    {-1},
#line 16 "aliases.gperf"
    {(int)(long)&((struct stringpool_t *)0)->stringpool_str26, ei_ascii},
    {-1},
#line 14 "aliases.gperf"
    {(int)(long)&((struct stringpool_t *)0)->stringpool_str28, ei_ascii},
#line 27 "aliases.gperf"
    {(int)(long)&((struct stringpool_t *)0)->stringpool_str29, ei_ucs2be},
#line 24 "aliases.gperf"
    {(int)(long)&((struct stringpool_t *)0)->stringpool_str30, ei_ucs2},
#line 40 "aliases.gperf"
    {(int)(long)&((struct stringpool_t *)0)->stringpool_str31, ei_utf16le},
#line 38 "aliases.gperf"
    {(int)(long)&((struct stringpool_t *)0)->stringpool_str32, ei_utf16},
    {-1}, {-1},
#line 19 "aliases.gperf"
    {(int)(long)&((struct stringpool_t *)0)->stringpool_str35, ei_ascii},
#line 39 "aliases.gperf"
    {(int)(long)&((struct stringpool_t *)0)->stringpool_str36, ei_utf16be},
#line 29 "aliases.gperf"
    {(int)(long)&((struct stringpool_t *)0)->stringpool_str37, ei_ucs2be},
#line 45 "aliases.gperf"
    {(int)(long)&((struct stringpool_t *)0)->stringpool_str38, ei_utf7},
    {-1},
#line 65 "aliases.gperf"
    {(int)(long)&((struct stringpool_t *)0)->stringpool_str40, ei_euc_cn},
#line 46 "aliases.gperf"
    {(int)(long)&((struct stringpool_t *)0)->stringpool_str41, ei_utf7},
#line 30 "aliases.gperf"
    {(int)(long)&((struct stringpool_t *)0)->stringpool_str42, ei_ucs2be},
    {-1}, {-1},
#line 23 "aliases.gperf"
    {(int)(long)&((struct stringpool_t *)0)->stringpool_str45, ei_utf8},
#line 51 "aliases.gperf"
    {(int)(long)&((struct stringpool_t *)0)->stringpool_str46, ei_c99},
#line 59 "aliases.gperf"
    {(int)(long)&((struct stringpool_t *)0)->stringpool_str47, ei_iso8859_1},
    {-1}, {-1},
#line 49 "aliases.gperf"
    {(int)(long)&((struct stringpool_t *)0)->stringpool_str50, ei_ucs4internal},
#line 43 "aliases.gperf"
    {(int)(long)&((struct stringpool_t *)0)->stringpool_str51, ei_utf32le},
#line 15 "aliases.gperf"
    {(int)(long)&((struct stringpool_t *)0)->stringpool_str52, ei_ascii},
    {-1}, {-1},
#line 13 "aliases.gperf"
    {(int)(long)&((struct stringpool_t *)0)->stringpool_str55, ei_ascii},
#line 42 "aliases.gperf"
    {(int)(long)&((struct stringpool_t *)0)->stringpool_str56, ei_utf32be},
#line 41 "aliases.gperf"
    {(int)(long)&((struct stringpool_t *)0)->stringpool_str57, ei_utf32},
    {-1},
#line 22 "aliases.gperf"
    {(int)(long)&((struct stringpool_t *)0)->stringpool_str59, ei_ascii},
#line 47 "aliases.gperf"
    {(int)(long)&((struct stringpool_t *)0)->stringpool_str60, ei_ucs2internal},
#line 12 "aliases.gperf"
    {(int)(long)&((struct stringpool_t *)0)->stringpool_str61, ei_ascii},
#line 20 "aliases.gperf"
    {(int)(long)&((struct stringpool_t *)0)->stringpool_str62, ei_ascii},
    {-1},
#line 32 "aliases.gperf"
    {(int)(long)&((struct stringpool_t *)0)->stringpool_str64, ei_ucs2le},
#line 28 "aliases.gperf"
    {(int)(long)&((struct stringpool_t *)0)->stringpool_str65, ei_ucs2be},
#line 34 "aliases.gperf"
    {(int)(long)&((struct stringpool_t *)0)->stringpool_str66, ei_ucs4},
    {-1}, {-1},
#line 50 "aliases.gperf"
    {(int)(long)&((struct stringpool_t *)0)->stringpool_str69, ei_ucs4swapped},
#line 57 "aliases.gperf"
    {(int)(long)&((struct stringpool_t *)0)->stringpool_str70, ei_iso8859_1},
    {-1}, {-1}, {-1}, {-1}, {-1},
#line 25 "aliases.gperf"
    {(int)(long)&((struct stringpool_t *)0)->stringpool_str76, ei_ucs2},
    {-1}, {-1},
#line 48 "aliases.gperf"
    {(int)(long)&((struct stringpool_t *)0)->stringpool_str79, ei_ucs2swapped},
#line 53 "aliases.gperf"
    {(int)(long)&((struct stringpool_t *)0)->stringpool_str80, ei_iso8859_1},
    {-1}, {-1}, {-1}, {-1},
#line 54 "aliases.gperf"
    {(int)(long)&((struct stringpool_t *)0)->stringpool_str85, ei_iso8859_1},
#line 55 "aliases.gperf"
    {(int)(long)&((struct stringpool_t *)0)->stringpool_str86, ei_iso8859_1},
#line 64 "aliases.gperf"
    {(int)(long)&((struct stringpool_t *)0)->stringpool_str87, ei_euc_cn},
    {-1}, {-1}, {-1}, {-1}, {-1}, {-1}, {-1}, {-1},
#line 66 "aliases.gperf"
    {(int)(long)&((struct stringpool_t *)0)->stringpool_str96, ei_euc_cn},
#line 58 "aliases.gperf"
    {(int)(long)&((struct stringpool_t *)0)->stringpool_str97, ei_iso8859_1},
    {-1}, {-1},
#line 56 "aliases.gperf"
    {(int)(long)&((struct stringpool_t *)0)->stringpool_str100, ei_iso8859_1},
    {-1},
#line 61 "aliases.gperf"
    {(int)(long)&((struct stringpool_t *)0)->stringpool_str102, ei_iso8859_1},
#line 52 "aliases.gperf"
    {(int)(long)&((struct stringpool_t *)0)->stringpool_str103, ei_java},
    {-1},
#line 18 "aliases.gperf"
    {(int)(long)&((struct stringpool_t *)0)->stringpool_str105, ei_ascii},
    {-1}, {-1}, {-1}, {-1}, {-1}, {-1}, {-1}, {-1}, {-1},
#line 17 "aliases.gperf"
    {(int)(long)&((struct stringpool_t *)0)->stringpool_str115, ei_ascii}
  };

#ifdef __GNUC__
__inline
#ifdef __GNUC_STDC_INLINE__
__attribute__ ((__gnu_inline__))
#endif
#endif
const struct alias *
aliases_lookup (register const char *str, register unsigned int len)
{
  if (len <= MAX_WORD_LENGTH && len >= MIN_WORD_LENGTH)
    {
      register int key = aliases_hash (str, len);

      if (key <= MAX_HASH_VALUE && key >= 0)
        {
          register int o = aliases[key].name;
          if (o >= 0)
            {
              register const char *s = o + stringpool;

              if (*str == *s && !strcmp (str + 1, s + 1))
                return &aliases[key];
            }
        }
    }
  return 0;
}
